**This file is not mandatory**

Took inspiration from the original stupid backoff algorithm documents.