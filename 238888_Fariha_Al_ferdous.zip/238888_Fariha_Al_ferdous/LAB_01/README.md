**This file is not mandatory**
Did a little change in the given statistics function of the lab exercise as the original function giving different output for spacy compared to the reference.
