**This file is not mandatory**

Took inspiration from https://github.com/monologg/JointBERT